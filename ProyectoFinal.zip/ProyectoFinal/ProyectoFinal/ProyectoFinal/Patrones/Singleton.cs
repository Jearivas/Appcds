﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectViews.Patrones
{
    public class Singleton
    {
        //Declaracion de variable estatica que mantendra la instancia
        private static Singleton _instancia;
        //Declaracion de variable de recurso global
        private ReposMem repositorio;

        //Declaracion de propiedad de acceso para la instancia de forma controlada
        public static Singleton Instancia
        {
            get
            {
                //Validamos si se encuentra instanciado
                if (_instancia == null)
                {
                    //Creamos una nueva instancia
                    _instancia = new Singleton();
                }
                return _instancia;
            }
        }
        //Declaracion de metodos y funciones para los recursos globales
        //-------------------------------------------------------------
        protected Singleton()
        {
            this.repositorio = new ReposMem();
        }

        public ReposMem Repositorio
        {
            get
            {
                return this.repositorio;
            }
        }
    }
}
