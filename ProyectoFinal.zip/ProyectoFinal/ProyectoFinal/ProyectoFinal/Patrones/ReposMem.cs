﻿using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Models.NoLogin;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectViews.Patrones
{
    public class ReposMem
    {                         
        //*******************************************************************************************************************************************************
        public List<UserDBLocal> ListaUser = new List<UserDBLocal>();

        public bool OperacionListas(UserDBLocal User, OperacionesFachada.Operaciones operaciones)
        {
            switch (operaciones)
            {
                case OperacionesFachada.Operaciones.Guardar:
                    ListaUser.Add(User);
                    return true;
                case OperacionesFachada.Operaciones.Editar:
                    return true;
                case OperacionesFachada.Operaciones.Eliminar:
                    int indexado = ListaUser.FindIndex(userr => userr.IdUsuario.Equals(User.IdUsuario));
                    ListaUser.RemoveAt(indexado);
                    return true;
                default:
                    return false;
            }
        }

        public UserDBLocal GetUserDBLocal(int Id, int IdUsuario)
        {
            try
            {
                //UBICACIÓN DEL REGISTRO EN LA LISTA
                int Index = ListaUser.FindIndex(userr => userr.ID.Equals(Id) && userr.IdUsuario.Equals(IdUsuario));
                return ListaUser[Index];
            }
            catch (Exception)
            {

                return null;
            }
        }
        public List<UserDBLocal> ObtenerUsuario()
        {
            return ListaUser;
        }
    }
}
