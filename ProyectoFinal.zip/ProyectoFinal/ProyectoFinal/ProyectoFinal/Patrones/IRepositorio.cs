﻿using ProyectoFinal.Models;
using ProyectoFinal.Models.NoLogin;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectViews.Patrones
{
    public static class OperacionesFachada
    {
        //Patron fachada 
        public enum Operaciones
        {
            Guardar,
            Editar,
            Eliminar
        }
    }
    public interface IRepositorio
    {
        UserDBLocal GetUserDBLocal(int Id, int IdUsuario);
    }
}
