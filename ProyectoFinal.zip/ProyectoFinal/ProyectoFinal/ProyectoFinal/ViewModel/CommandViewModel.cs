﻿using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Views;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;
using ProyectViews.Patrones;
using ProyectoFinal.Models;

namespace ProyectoFinal.ViewModel
{
    public class CommandViewModel
    {
        public ObservableCollection<ResultEvents> Eventos { get; set; }
        public INavigation Navegacion { get; set; }
        public ICommand IRMaster { get; set; }        
        public ICommand BandejaEntrada { get; set; }
        public ICommand DetallesEventos { get; set; }
        
        public ICommand IngresarCommand { get; set; }
        
        public ICommand Regresar { get; set; }
        public Page _page;
      
        public CommandViewModel(Page pag,INavigation nav)
        {
            this.Navegacion = nav;
            IngresarCommand = new Command(Add);
            IRMaster = new Command(MAsterdetail);            
                                  
            Regresar = new Command(Volver);           
            
        }
                
        void Add()
        {
            this.Navegacion.PushAsync(new AddRegistro());
        }       
        void Mensaje()
        {
            this.Navegacion.PushAsync(new Docentes());
        }
        void MAsterdetail()
        {            
            this.Navegacion.RemovePage(this._page);
        }
                      
        public async void Volver()
        {
            await PopupNavigation.Instance.PopAsync();
        }
    }
}


