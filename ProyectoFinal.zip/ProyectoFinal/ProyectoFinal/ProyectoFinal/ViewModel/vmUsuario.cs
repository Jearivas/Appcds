﻿using Acr.UserDialogs;
using ProyectoFinal.Models;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Models.NoLogin;
using ProyectoFinal.Views;
using ProyectViews.Patrones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class vmUsuario : BindableObject
    {
        //Declaracion de variable para navegacion
        public INavigation nNavegation { get; set; }

        //Variables para encapsular el login
        public string login { get; set; }
        public string pass { get; set; }

        public static ResultUser userencontrado { get; set; }

        //Instancias
        LoginJson loginJson = new LoginJson();

        //Instancia donde se encuenta la peticion del POST
        RestUsuario _Client = new RestUsuario();
        UserDBLocal _user;

        //Encapsulamiento de datos
        public String Login { get { return loginJson.Login; } set { loginJson.Login = value; OnPropertyChanged(); } }
        public String Pass { get { return loginJson.Pass; } set { loginJson.Pass = value; OnPropertyChanged(); } }
        public int IdUsuario { get { return loginJson.IdUsuario; } set { loginJson.IdUsuario = value; } }

        private INavigation navegar;
        Page _page;

        //Constructor de la clase
        public vmUsuario(Page pPage, INavigation nav)
        {
            _page = pPage;
            navegar = nav;
        }

        //*******************************************************************************************************************************************************

        //Commando para el login
        public ICommand LoginCommand { get { return new Command(async () => await Ingresar()); } }

        //Commando para el login
        public async Task Ingresar()
        {

            try
            {
                //mostramos un mensaje de espera

                //validacion para el acceso
                if (string.IsNullOrEmpty(Login) || string.IsNullOrEmpty(Pass))
                {
                    await _page.DisplayAlert("Aviso", "Campos vacíos", "Aceptar");
                }
                else
                {

                    loginJson.Login = Login;
                    loginJson.Pass = Pass;
                    userencontrado = await _Client.logUser(loginJson);
                    if (userencontrado != null)
                    {
                        using (UserDialogs.Instance.Loading("Cargando...", null, null, true, MaskType.Black))
                        {
                            await Task.Delay(2000);
                            if (userencontrado.esDocente)
                            {

                                //si el login es correcto guardar id del usuario el local db
                                _user = new UserDBLocal() { IdUsuario = userencontrado.IdDocente, EsDocente = userencontrado.esDocente };
                                await DBUser.Instance.conexion.InsertAsync(_user);
                                Settings.IsLoggedIn = true;

                                //enviar el id a la mastery, creamos el objeto que mantiene la sesion
                                vmUsuario.userencontrado = new ResultUser();
                                vmUsuario.userencontrado.IdUsuario = _user.IdUsuario;
                                vmUsuario.userencontrado.esDocente = _user.EsDocente;

                                await navegar.PushAsync(new MasterDetail(vmUsuario.userencontrado.IdUsuario));
                                this.navegar.RemovePage(this._page);
                            }
                            else if (!userencontrado.esDocente)
                            {
                                //si el login es correcto guardar id del usuario el local db
                                _user = new UserDBLocal() { IdUsuario = userencontrado.IdParticipante, EsDocente = userencontrado.esDocente }; ;
                                await DBUser.Instance.conexion.InsertAsync(_user);
                                Settings.IsLoggedIn = true;

                                //enviar el id a la mastery, creamos el objeto que mantiene la sesion
                                vmUsuario.userencontrado = new ResultUser();
                                vmUsuario.userencontrado.IdUsuario = _user.IdUsuario;
                                vmUsuario.userencontrado.esDocente = _user.EsDocente;

                                await navegar.PushAsync(new MasterDetail(vmUsuario.userencontrado.IdUsuario));
                                this.navegar.RemovePage(this._page);
                            }
                        }
                    }

                    else
                    {
                        await _page.DisplayAlert("Aviso", "Usuario no encontrado", "Aceptar");
                    }
                }
            }
            catch (Exception)
            {
                await _page.DisplayAlert("Aviso", "Usuario y Contraseña son invalidos", "Aceptar");
            }
        }
    }
}

