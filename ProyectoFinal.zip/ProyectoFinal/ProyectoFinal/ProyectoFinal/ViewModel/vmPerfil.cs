﻿using ProyectoFinal.Models.Conexion;
using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Net.Http;
using Newtonsoft.Json;
using System.Collections.ObjectModel;

namespace ProyectoFinal.ViewModel
{
    public class vmPerfil : BindableObject
    {
        
        //Lista
        private ObservableCollection<ResultPerfil> _perfiles;
        public ObservableCollection<ResultPerfil> Perfiles
        {
            get
            {
                return _perfiles;
            }
            set
            {
                if (_perfiles == value)
                {
                    return;
                }
                _perfiles = value;
                OnPropertyChanged("Perfiles");
            }
        } 

        //Instancia de la clase que contiene los datos del Json
        ResultPerfil resultPerfil = new ResultPerfil();
        //Variable que contiene la Url
        string URL = "http://192.168.42.139/APICDS/CDSservices.asmx/GetPerfil";
        //============================================================================================================================================
        //Encapsulamiento de datos
        //Variables para encapsular
        public string Nombre { get { return resultPerfil.Nombre; } set { resultPerfil.Nombre = value; OnPropertyChanged(); } }
        public string Identificacion { get { return resultPerfil.Identificacion; } set { resultPerfil.Identificacion = value; OnPropertyChanged(); } }
        public string Correo { get { return resultPerfil.Correo; } set { resultPerfil.Correo = value; OnPropertyChanged(); } }
        public string Telefono { get { return resultPerfil.Telefono; } set { resultPerfil.Telefono = value; OnPropertyChanged(); } }
        //============================================================================================================================================               
        public vmPerfil()
        {
            Perfiles = new ObservableCollection<ResultPerfil>();
            OnAppering();
        }
       
        public async void OnAppering()
        {
            HttpClient _client = new HttpClient();
            //======================================================================================
            //Variables para verificar y asi mostrar que tipo de Usuario es...
            int IdDocent = 0;
            int IdParticipante = 0;

            //Validamos si es docente
            if (vmUsuario.userencontrado.esDocente)
            {
                IdDocent = vmUsuario.userencontrado.IdUsuario;
            }else {
                IdParticipante = vmUsuario.userencontrado.IdUsuario;
            }
            bool esDocente = vmUsuario.userencontrado.esDocente;
            String IdUsuario = "IdUsuario=";
            String docente = "docente=";
            //======================================================================================                        
            //Condicion 
            if (IdDocent != 0 & esDocente == true)
            {
                
                var Usuario = IdUsuario + Convert.ToString(IdDocent);
                var Docente = docente + "1";
                //Instancia para el GET
                
                HttpResponseMessage Result = await _client.GetAsync(this.URL + "?" + Usuario + "&" + Docente);
                if (Result != null)
                {
                    var contenido = await Result.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<ResultPerfil>>(contenido);
                    foreach (var item in resultados)
                    {
                        Perfiles.Add(item);
                    }
                }

            }
            else if (IdParticipante != 0 & esDocente == false)
            {
               var  _Usuario = IdUsuario + Convert.ToString(IdParticipante);
               var  _Docente = docente + "0";
                //Instancia para el GET
                HttpClient httpClient = new HttpClient();
                HttpResponseMessage Result = await httpClient.GetAsync(this.URL + "?" + _Usuario + "&" + _Docente);
                if (Result != null)
                {
                    var contenido = await Result.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<ResultPerfil>>(contenido);
                    foreach (var item in resultados)
                    {
                        Perfiles.Add(item);
                    }
                }
            }
        }           
    }
}

