﻿using MvvmHelpers;
using ProyectoFinal.Models;
using ProyectoFinal.Views;
using ProyectoFinal.Models.Conexion;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class vmMessage : BindableObject
    {
        //=============================================
        //Comando para navegar la vista de la searchbar
        public INavigation navigation { get; set; }
        public ICommand IrSearch { get; set; }

        Message _Message = new Message();
        RestMessage restMessage = new RestMessage();
        public int ID { get; set; }
        public int IDdocente { get { return _Message.idDocente; } set { _Message.idDocente = value; OnPropertyChanged(); } }
        public int IDParticipante { get { return _Message.idParticipante; } set { _Message.idParticipante = value; OnPropertyChanged();} }
        public int IDMsj { get { return _Message.idMensaje; } set { _Message.idMensaje = value; OnPropertyChanged(); } }
        public String Participante { get { return _Message.Participante; } set { _Message.Participante = value; OnPropertyChanged(); } }
        public String Docente { get { return _Message.Docente; } set { _Message.Docente = value; OnPropertyChanged(); } }
        public String Texto { get { return _Message.Text; } set { _Message.Text = value; OnPropertyChanged(); } }
        public String TituloMsj { get { return _Message.TituloMsj; } set { _Message.TituloMsj = value; OnPropertyChanged(); } }

        public Page page;
        public vmMessage(Page pagina, INavigation nav)
        {
            navigation = nav;
            page = pagina;
        }
        
        public ICommand SendCommand { get { return new Command(async () => await SendMessage()); } }

        //Fun para enviar los mensajes
        public async Task SendMessage()
        {
            //IDdocente = 1;
            //IDMsj = 1;
            try
            {
                //Validaciones para verificar el ID si este usuario es docente o Participante
                if (_Message.idParticipante == IDParticipante)
                {
                    _Message.idParticipante = IDParticipante;
                    _Message.idMensaje = IDMsj;
                    _Message.Participante = Participante;
                    _Message.Text = Texto;
                    _Message.TituloMsj = TituloMsj;
                    if (!String.IsNullOrEmpty(Participante) && !String.IsNullOrEmpty(Texto) && !String.IsNullOrEmpty(TituloMsj))
                    {
                        await restMessage.EnviarMensaje(_Message);
                        await page.DisplayAlert("Aviso", "¡Mensaje Enviado!", "Aceptar");

                        this.Participante = String.Empty;
                        this.Texto = String.Empty;
                        this.TituloMsj = String.Empty;
                    }
                    else
                    {
                        await page.DisplayAlert("Aviso", "Mensaje no enviado", "Aceptar");
                    }                    
                }
                else if (_Message.idDocente == IDdocente )
                {
                    _Message.idDocente = IDdocente;
                    _Message.idMensaje = IDMsj;
                    _Message.Docente = Docente;
                    _Message.Text = Texto;
                    _Message.TituloMsj = TituloMsj;
                    if (!String.IsNullOrEmpty(Docente)&&!String.IsNullOrEmpty(Texto) && !String.IsNullOrEmpty(TituloMsj))
                    {
                        await restMessage.EnviarMensaje(_Message);

                        await page.DisplayAlert("Aviso", "¡Mensaje Enviado!", "Aceptar");
                        this.Docente = String.Empty;
                        this.Texto = String.Empty;
                        this.TituloMsj = String.Empty;
                    }
                    else
                    {
                        await page.DisplayAlert("Aviso", "Mensaje no enviado", "Aceptar");
                    }
                }
                else
                {
                    await page.DisplayAlert("Aviso", "Mensaje no enviado", "Aceptar");
                }
            }
            catch (Exception)
            {
                throw;
            }            
        }        
    }
}
