﻿using Newtonsoft.Json;
using ProyectoFinal.Models.Conexion;
using ProyectoFinal.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class vmVerMensajes
    {
        INavigation navigation;
        ICommand Envio { get; set; }
        string URL = "http://192.168.42.139/APICDS/CDSservices.asmx/getMensaje";
        public ObservableCollection<RestMensajesRecibidos> Mensajes { get; set; }
        public vmVerMensajes(INavigation nav)
        {
            this.navigation = nav;
            Mensajes = new ObservableCollection<RestMensajesRecibidos>();
            InboxMessage();
            Envio = new Command(Responder);
        }
        public async void InboxMessage()
        {
            //Variables para verificar y asi mostrar que tipo de Usuario es...
            int IdDocent = 0;
            int IdParticipante = 0;
            HttpClient cliente = new HttpClient();
            String IdUsuario = "IdUsuario=";
            String docente = "docente=";
            //Validamos si es docente
            if (vmUsuario.userencontrado.esDocente)
            {
                IdDocent = vmUsuario.userencontrado.IdUsuario;
            }
            else
            {
                IdParticipante = vmUsuario.userencontrado.IdUsuario;
            }
            bool esDocente = vmUsuario.userencontrado.esDocente;
            //======================================================================================
            //Condicion
            if (IdDocent != 0 & esDocente==true)
            {
                var Usuario = IdUsuario + Convert.ToString(IdDocent);
                var Docente = docente + "1";
                //Instancia para el GET
                HttpResponseMessage Result = await cliente.GetAsync(this.URL + "?" + Usuario + "&" + Docente);
                if (Result != null )
                {
                    var contenido = await Result.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<RestMensajesRecibidos>>(contenido);
                    foreach (var item in resultados)
                    {
                        Mensajes.Add(item);
                    }
                }
            }
            else if (IdParticipante != 0 & esDocente==false)
            {
                var _Usuario = IdUsuario + Convert.ToString(IdParticipante);
                var _Docente = docente + "0";
                //Instancia para el GET
                HttpClient HtpCliente = new HttpClient();
                HttpResponseMessage Resulta = await HtpCliente.GetAsync(this.URL + "?" + _Usuario + "&" + _Docente);
                if (Resulta != null)
                {
                    var contenido = await Resulta.Content.ReadAsStringAsync();
                    var resultados = JsonConvert.DeserializeObject<List<RestMensajesRecibidos>>(contenido);
                    foreach (var item in resultados.OrderByDescending(c => c.IdMensaje))
                    {
                        Mensajes.Add(item);
                    }
                }
            }
        }
        public void Responder()
        {
            navigation.PushAsync(new Docentes());
        }
    }
}
