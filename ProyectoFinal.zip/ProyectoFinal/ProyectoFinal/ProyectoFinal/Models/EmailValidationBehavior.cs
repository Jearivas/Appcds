﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace ProyectoFinal.ViewModel
{
    public class EmailValidationBehavior:Behavior<Entry>
    {
        protected override void OnAttachedTo(Entry bindable)
        {
            //configuramos los comportamientos Extras
            base.OnAttachedTo(bindable);

            bindable.TextChanged += BindableOnTextChanged;
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            //Limpiamos la referencia de los eventos
            base.OnAttachedTo(bindable);

            bindable.TextChanged -= BindableOnTextChanged;
        }

        //Comportamiento extra para el Entry
        //==============================================
        private void BindableOnTextChanged(object sender, TextChangedEventArgs e)
        {
            var email = e.NewTextValue;
            var emailPattern = "^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$";
            var emailEntry = sender as Entry;
            //Realizamos evento que muestra que el valor no es valido
            if (Regex.IsMatch(email, emailPattern))
            {
                emailEntry.TextColor = Color.FromHex("#143F62");
            }
            else
            {
                emailEntry.TextColor = Color.Red;
            }
        }
    }
}
