﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class ID
    {
        //Declaracion de variables para los Idenificadores
        public int Usuario1Id { get; set; }
        public int Usuario2Id { get; set; }
    }
}
