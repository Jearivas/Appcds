﻿using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class Message : ObservableObject
    {
        //Clase de Enviar Mensaje para el Json del POST 

        [JsonProperty("Participante")]
        public string Participante
        {
            get { return _participante; }
            set { SetProperty(ref _participante, value); }
        }
        string _participante;

        [JsonProperty("Docente")]
        public string Docente
        {
            get { return _docente; }
            set { SetProperty(ref _docente, value); }
        }
        string _docente;

        [JsonProperty("Mensaje1")]
        public string Text
        {
            get { return _text; }
            set { SetProperty(ref _text, value); }
        }
        string _text;

        [JsonProperty("TituloMensaje")]
        public string TituloMsj
        {
            get { return _titulomsj; }
            set { SetProperty(ref _titulomsj, value); }
        }
        string _titulomsj;

        //ID´s
        [JsonProperty("IdMensaje")]
        public int idMensaje { get; set; }
        [JsonProperty("IdDocente")]
        public int idDocente { get; set; }
        [JsonProperty("IdParticipante")]
        public int idParticipante { get; set; }
        [JsonProperty("idUsuarioEnvia")]
        public int idUsuarioEnvia { get; set; }
        [JsonProperty("idUsuarioReceptor")]
        public int idUsuarioReceptor { get; set; }
        [JsonProperty("receptorDocente")]
        public int receptorDocente { get; set; }
        [JsonProperty("enviaDocente")]
        public int enviaDocente { get; set; }
    }
}
