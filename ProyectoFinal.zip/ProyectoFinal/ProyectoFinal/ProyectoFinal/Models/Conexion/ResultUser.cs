﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.Conexion
{
    public class ResultUser
    {

        //Usuario general para navegacion
        public int IdUsuario { get; set; }
        //Clase que contiene el Json
        public int IdParticipante { get; set; }
        public int IdDocente { get; set; }
        public bool esDocente { get; set; }
        public string Codigo { get; set; }
        public string Mensaje { get; set; }
    }
}
