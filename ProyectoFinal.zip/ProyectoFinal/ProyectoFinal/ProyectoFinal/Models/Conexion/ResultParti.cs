﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.Conexion
{
  
    public class ResultParti
    {
        public int IdParticipante { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string CodParticipante { get; set; }

        public static List<ResultParti> listados;
    }
}
