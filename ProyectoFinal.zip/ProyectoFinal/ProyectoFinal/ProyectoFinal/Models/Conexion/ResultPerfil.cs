﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.Conexion
{   
    public class ResultPerfil
    {
        public string Nombre { get; set; }
        public string Identificacion { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }

        public static List<ResultPerfil> listados;
    }
}
