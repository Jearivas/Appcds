﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models.Conexion
{
    public class RestMensajesRecibidos
    {
        //Variables para el recibo de mensajes
        public int IdMensaje { get; set; }
        public string TituloMensaje { get; set; }
        public string Mensaje1 { get; set; }
        public int IdDocente { get; set; }
        public string Docente { get; set; }
        public int IdParticipante { get; set; }
        public string Participante { get; set; }

        public static List<RestMensajesRecibidos> listados;
    }
}
