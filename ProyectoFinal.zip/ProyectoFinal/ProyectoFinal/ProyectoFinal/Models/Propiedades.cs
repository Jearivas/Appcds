﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class Propiedades
    {
        public string Nombre { get; set; }
        public string Detalles { get; set; }
    }
}
