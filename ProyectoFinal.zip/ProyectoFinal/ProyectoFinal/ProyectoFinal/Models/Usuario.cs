﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProyectoFinal.Models
{
    public class Usuario
    {
        //Clase que contiene la informacion de usuario
        public int UsuarioID { get; set; }
        public String Nombre { get; set; }
        public String Apellido { get; set; }
        public String login { get; set; }
        public String pass { get; set; }
    }
}
