﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Models.Interfaces
{
    public interface IMessage
    {        
        Task<bool> EnviarMensaje(Message message);
    }
}
