﻿using ProyectoFinal.ViewModel;
using ProyectViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinal.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Listas : ContentPage
	{
		public Listas ()
		{
			InitializeComponent ();
            BindingContext = new BaseLista();           
        }
        //metodo para seleccionar el Item
        public void ItemSelet(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return;
            }
            var command = ((BaseLista)BindingContext).ItemSelected;
            if (command != null && command.CanExecute(e.SelectedItem))
            {
                command.Execute(e.SelectedItem);
            }
            ((ListView)sender).SelectedItem = false;
        }
        
        //variable tipo ViewCell para el metodo de color de fondo
        ViewCell lastCell;
        //Metodo para cambiar el color de fondo al momento de seleccionar el Item
        private void ViewCell_Tapped(object sender, System.EventArgs e)
        {
            if (lastCell != null)
                lastCell.View.BackgroundColor = Color.Transparent;
            var viewCell = (ViewCell)sender;
            if (viewCell.View != null)
            {
                viewCell.View.BackgroundColor = Color.WhiteSmoke;
                lastCell = viewCell;
            }
        }
    }
}