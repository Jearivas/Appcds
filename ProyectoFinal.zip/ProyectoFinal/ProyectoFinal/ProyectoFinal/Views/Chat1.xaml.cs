﻿using ProyectoFinal.Models.Conexion;
using ProyectoFinal.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProyectoFinal.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Chat1 : ContentPage
	{
		public Chat1 (RestMensajesRecibidos mensajes)
		{
			InitializeComponent ();
            BindingContext = new vmVerMensajes(Navigation);

            if (mensajes.Docente!=null)
            {
                EnviadoPor.Text = mensajes.Docente.ToString();                
                Titulo.Text = mensajes.TituloMensaje.ToString();
                LabelMsj.Text = mensajes.Mensaje1.ToString();
            }
            else if(mensajes.Participante!= null)
            {                
                EnviadoPor2.Text = mensajes.Participante.ToString();
                Titulo.Text = mensajes.TituloMensaje.ToString();
                LabelMsj.Text = mensajes.Mensaje1.ToString();
            }            
        }        
    }
}